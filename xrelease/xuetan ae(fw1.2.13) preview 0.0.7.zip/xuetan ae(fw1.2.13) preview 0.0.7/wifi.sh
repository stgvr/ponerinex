#!/bin/sh
GATE="192.168.31.1"
# CHANGE TO 101,102,103,104,105,106,107
IPAD="192.168.31.101"
# IPAD="DHCP"

#wpa_supplicant.conf
WPAS=/tmp/fuse_a/custom/wpa_supplicant.conf

wait_wlan0()
{
  n=0
  ifconfig wlan0
  waitagain=$?
  while [ $n -ne 6 ] && [ $waitagain -ne 0 ]; do
    n=$(($n + 1))
    echo $n
    sleep 1
    ifconfig wlan0
    waitagain=$?
  done
}

wifi_station()
{
  MAC=`cat /tmp/wifi0_mac`
  
  killall -9 hostapd hostapd_autochannel_retartchip dnsmasq udhcpc wpa_supplicant wpa_cli wpa_event.sh 2> /dev/null
  killall -9 hostapd hostapd_autochannel_retartchip dnsmasq udhcpc wpa_supplicant wpa_cli wpa_event.sh 2> /dev/null
  rmmod bcmdhd

  insmod /lib/modules/bcmdhd.ko firmware_path=/usr/local/bcmdhd/fw_apsta.bin nvram_path=/usr/local/bcmdhd/nvram.txt iface_name=wlan dhd_msg_level=0x00 op_mode=1 amba_initmac=${MAC}
  wait_wlan0
  driver=nl80211

  /usr/bin/wpa_supplicant -D${driver} -iwlan0 -c${WPAS} -B
  sleep 5
  if [ "${IPAD}" == "DHCP" ]; then
    udhcpc -i wlan0 -A 2 -b -t 30
  else
    ifconfig wlan0 $IPAD netmask 255.255.255.0
  fi
}

#keep wifi alive
keep_wifi_alive()
{
  # pint count
  COUNT=10
  # reset percentage
  PERCENT=70
  # ping timeout
  WAIT=3
  LAST=1
  while [ 1 ]; do
    GPIO=`cat /proc/ambarella/gpio`
    WIFI=${GPIO:11:1}
    # if wifi off then wait 5
    if [ $WIFI -eq 0 ]; then
      sleep 5
    # if wifi just turn on
    elif [ $LAST -eq 0 ]; then
      sleep 5
      wifi_station
    else
      result=$(ping -W $WAIT -c $COUNT $GATE | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
      if [ $result -lt $(( $COUNT * $PERCENT / 100 )) ]; then
        GPIO=`cat /proc/ambarella/gpio`
        WIFI=${GPIO:11:1}
        # if wifi on then restart wifi mode
        if [ $WIFI -eq 1 ]; then
          wifi_station
        fi
      fi
    fi
    LAST=$WIFI
  done
}

# Program starts from here
LOGS="/tmp/wifi.log"
GPIO=`cat /proc/ambarella/gpio`
WIFI=${GPIO:11:1}
# Wait for wifi turn on
while [ $WIFI -eq 0 ]; do
  sleep 3
  GPIO=`cat /proc/ambarella/gpio`
  WIFI=${GPIO:11:1}
done
# if wifi on start wifi mode
wifi_station
keep_wifi_alive
