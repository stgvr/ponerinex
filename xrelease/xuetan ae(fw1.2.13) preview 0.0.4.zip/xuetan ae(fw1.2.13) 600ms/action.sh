#!/bin/sh

if [ $# -eq 0 ] || [ "${1}" == "--help" ] ; then
  echo "Usage:"
  echo "action.sh --help"
  echo "    show help information"
  echo "action.sh [ash_file_name]"
  echo "    run amba shell file"
  exit 0
fi

CUSTOM=/tmp/fuse_a/custom/
ACTASH=/tmp/fuse_a/custom/action.ash

if [ -f $ACTASH ]; then
  rm -f $ACTASH
fi

cp -f $CUSTOM$1 $ACTASH
