#!/bin/sh

echo $1 $2 $3 $4 > /tmp/fuse_a/custom/asid.txt
