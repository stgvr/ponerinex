#!/bin/sh

ASID=/tmp/fuse_a/custom/asid.txt

while [ ! -f $ASID ]; do
  sleep 1
done

echo [A/S/I/D]`cat $ASID`[A/S/I/D]
