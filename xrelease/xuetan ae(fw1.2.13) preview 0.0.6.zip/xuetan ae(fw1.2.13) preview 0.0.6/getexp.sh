#!/bin/sh

AETEXT=/tmp/fuse_a/custom/meter/aevalue.txt
ASID=/tmp/fuse_a/custom/asid.txt
METER=/tmp/fuse_a/custom/meter.ash
ACTION=/tmp/fuse_a/custom/action.ash

rm -f /tmp/fuse_a/custom/meter/*

cp -f $METER $ACTION

A=`ls -l $ACTION`

while [ ! -f $AETEXT ]; do
  sleep 1
done
# grep  A/S/I/D value
A=`cat $AETEXT | grep ae_info.agc_index | awk '{print $2}'`
S=`cat $AETEXT | grep ae_info.shutter_index | awk '{print $2}'`
I=`cat $AETEXT | grep ae_info.iris_index | awk '{print $2}'`
D=`cat $AETEXT | grep ae_info.dgain | awk '{print $2}'`
# remove all the ituner files
rm -f /tmp/fuse_a/custom/meter/*
# save value to file
echo $A $S $I $D > $ASID
# print A/S/I/D message
echo [A/S/I/D]$A $S $I $D[A/S/I/D]
