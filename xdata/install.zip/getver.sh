#!/bin/sh

if [ -e /tmp/fuse_a/custom/version.txt ]; then
  VERS=`cat /tmp/fuse_a/custom/version.txt | grep '<scriptversion>' | awk -F'<scriptversion>' '{ print $2 }' | awk -F'</scriptversion>' '{ print $1 }'`
  echo [VERSION]$VERS[VERSION]
else
  echo [VERSION]0.0.0[VERSION]
fi
