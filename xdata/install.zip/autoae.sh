#!/bin/sh

AUTOAE=/tmp/fuse_a/custom/autoae.ash
ACTION=/tmp/fuse_a/custom/action.ash
ASID=/tmp/fuse_a/custom/asid.txt

# remove old action.ash
if [ -f $ACTION ]; then
  rm -f $ACTION
fi
# remove old asid.txt
if [ -f $ASID ]; then
  rm -f $ASID
fi
# rename autoae.ash to action.ash
cp -f $AUTOAE $ACTION
A=`ls -l $ACTION`
# wait for action.ash run
while [ ! -f $ASID ]; do
  sleep 1
done
# print A/S/I/D message
echo [A/S/I/D]`cat $ASID`[A/S/I/D]
