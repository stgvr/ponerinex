#!/bin/sh

if [ $# -eq 0 ]; then
  echo SET_EXPOSURE_ERR
  exit 0
fi

SETEXP=/tmp/fuse_a/custom/setexp.ash
ACTION=/tmp/fuse_a/custom/action.ash
ASID=/tmp/fuse_a/custom/asid.txt
ASIDSH=/tmp/fuse_a/custom/asid.sh

# remove old action.ash
if [ -f $ACTION ]; then
  rm -f $ACTION
fi
# remove old asid.txt
if [ -f $ASID ]; then
  rm -f $ASID
fi
# create setexp.ash
echo \# ash set exposure script > $SETEXP
echo t ia2 -ae off >> $SETEXP
echo sleep 1 >> $SETEXP
echo t ia2 -awb off >> $SETEXP
echo sleep 1 >> $SETEXP
echo lu_util exec \'rm -f $ACTION\' >> $SETEXP
echo sleep 1 >> $SETEXP
# echo a:/custom/buzzer.ash >> $SETEXP
# echo sleep 1 >> $SETEXP
echo t cal -me 0 $1 $2 $3 $4 >> $SETEXP
echo sleep 2 >> $SETEXP
echo lu_util exec \'$ASIDSH $1 $2 $3 $4\' >> $SETEXP
# rename setexp.ash to action.ash
mv -f $SETEXP $ACTION
A=`ls -l $ACTION`
# wait for action.ash run
while [ ! -f $ASID ]; do
  sleep 1
done
# print A/S/I/D message
echo [A/S/I/D]`cat $ASID`[A/S/I/D]
