#!/bin/sh

BUZZER=/tmp/fuse_a/custom/buzzer.ash
ACTION=/tmp/fuse_a/custom/action.ash
BUZLOG=/tmp/fuse_a/custom/buzzer.txt

# remove old action.ash
if [ -f $ACTION ]; then
  rm -f $ACTION
fi
# remove old buzzer.txt
if [ -f $BUZLOG ]; then
  rm -f $BUZLOG
fi
# rename buzzer.ash to action.ash
cp -f $BUZZER $ACTION
A=`ls -l $ACTION`
# wait for action.ash run
while [ ! -f $BUZLOG ]; do
  sleep 1
done
# print buzzer message
echo `cat $BUZLOG`
