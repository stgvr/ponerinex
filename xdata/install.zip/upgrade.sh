#!/bin/sh

write_wireless()
{
  if [ -e /tmp/fuse_a/custom/wpa_supplicant.conf ]; then
    SSID=`cat /tmp/fuse_a/custom/wpa_supplicant.conf | grep ssid | awk -F'"' '{ print $2 }'`
    WPSK=`cat /tmp/fuse_a/custom/wpa_supplicant.conf | grep psk | awk -F'"' '{ print $2 }'`
  fi
  GATE=`cat /tmp/fuse_a/custom/wifi.sh | grep GATE= | awk -F'"' '{ print $2 }'`
  IPAD=`cat /tmp/fuse_a/custom/wifi.sh | grep -v \# | grep IPAD= | awk -F'"' '{ print $2 }'`
  if [ "${GATE}" == "" ]; then
    IPAD=`ifconfig wlan0 | grep inet | awk '{ print $2 }' | awk -F':' '{ print $2 }'`
    GATE=`echo $IPAD | awk -F'.' '{ print $1"."$2"."$3".1" }'`
  fi
  echo "<ssid>$SSID</ssid>" > /tmp/wireless.conf
  echo "<psk>$WPSK</psk>" >> /tmp/wireless.conf
  echo "<ipaddress>$IPAD</ipaddress>" >> /tmp/wireless.conf
  echo "<gateway>$GATE</gateway>" >> /tmp/wireless.conf
}

if [ $# -eq 0 ]; then
  echo [UPGRADE]MISS_MD5_VALUE[UPGRADE]
  exit 0
fi

#check sum
MD5=`md5sum /tmp/install.zip | awk '{ print $1 }'`

if [ "${MD5}" != "${1}" ]; then
  echo [UPGRADE]WRONG_MD5_VALUE[UPGRADE]
  exit 0
fi

#stop custom programs
killall -9 wifi.sh yi_plus 2> /dev/null
#make dir
if [ ! -d /tmp/fuse_a/custom ]; then
  mkdir -p /tmp/fuse_a/custom
fi
#backup wireless
if [ ! -e /tmp/wireless.conf ]; then
  if [ -e /tmp/fuse_a/custom/wireless.conf ]; then
    cp -f /tmp/fuse_a/custom/wireless.conf /tmp/wireless.conf
  else
    write_wireless
  fi
fi
#remove old files
rm -r -f /tmp/fuse_a/custom/*
#unzip new files
unzip -o /tmp/install.zip -d /tmp/fuse_a/custom
#copy wireless
cp -f /tmp/wireless.conf /tmp/fuse_a/custom/wireless.conf
#change mode
chmod 777 /tmp/fuse_a/custom/*.*
#copy autoexec.ash
mv -f /tmp/fuse_a/custom/initial.ash /tmp/fuse_a/autoexec.ash
#start wifi
/tmp/fuse_a/custom/wifi.sh &
#upgrade result
echo [UPGRADE]SUCCESS[UPGRADE]
