#!/bin/sh

read_wireless()
{
  cp -f /tmp/fuse_a/custom/wireless.conf /tmp/wireless.conf
  #read wireless.conf
  WCONF=/tmp/wireless.conf
  if [ -e $WCONF ]; then
    SSID=`cat $WCONF | grep '<ssid>' | awk -F'<ssid>' '{ print $2 }' | awk -F'</ssid>' '{ print $1 }'`
    WPSK=`cat $WCONF | grep '<psk>' | awk -F'<psk>' '{ print $2 }' | awk -F'</psk>' '{ print $1 }'`
    IPAD=`cat $WCONF | grep '<ipaddress>' | awk -F'<ipaddress>' '{ print $2 }' | awk -F'</ipaddress>' '{ print $1 }'`
    GATE=`cat $WCONF | grep '<gateway>' | awk -F'<gateway>' '{ print $2 }' | awk -F'</gateway>' '{ print $1 }'`
  else
    SSID='stg01ab000'
    WPSK='stg01ab000'
    IPAD='DHCP'
    GATE='192.168.31.1'
  fi

  #wpa_supplicant.conf
  WPAS=/tmp/wpa_ponerinex.conf

  #create wpa_ponerinex.conf
  echo 'ctrl_interface=/var/run/wpa_supplicant' > $WPAS
  echo 'network={' >> $WPAS
  echo "ssid=\"${SSID}\"" >> $WPAS
  echo 'key_mgmt=WPA-PSK' >> $WPAS
  echo 'proto=WPA2 WPA' >> $WPAS
  echo 'pairwise=CCMP TKIP' >> $WPAS
  echo "psk=\"${WPSK}\"" >> $WPAS
  echo '}' >> $WPAS
}

wait_wlan0()
{
  n=0
  ifconfig wlan0
  waitagain=$?
  while [ $n -ne 6 ] && [ $waitagain -ne 0 ]; do
    n=$(($n + 1))
    echo $n
    sleep 1
    ifconfig wlan0
    waitagain=$?
  done
}

#set wifi to station mode
wifi_station()
{
  MAC=`cat /tmp/wifi0_mac`
  
  killall -9 hostapd hostapd_autochannel_retartchip dnsmasq udhcpc wpa_supplicant wpa_cli wpa_event.sh 2> /dev/null
  killall -9 hostapd hostapd_autochannel_retartchip dnsmasq udhcpc wpa_supplicant wpa_cli wpa_event.sh 2> /dev/null
  rmmod bcmdhd

  insmod /lib/modules/bcmdhd.ko firmware_path=/usr/local/bcmdhd/fw_apsta.bin nvram_path=/usr/local/bcmdhd/nvram.txt iface_name=wlan dhd_msg_level=0x00 op_mode=1 amba_initmac=${MAC}
  wait_wlan0
  driver=nl80211

  /usr/bin/wpa_supplicant -D${driver} -iwlan0 -c${WPAS} -B
  sleep 2
  if [ "${IPAD}" == "DHCP" ]; then
    udhcpc -i wlan0 -A 2 -b -t 30
  else
    ifconfig wlan0 $IPAD netmask 255.255.255.0
  fi
  sleep 2
  # save log to wifi.log
  if [ $WLOG -eq 1 ]; then
    echo `ifconfig wlan0` >> $SAVELOG
    echo `cat ${WPAS}` >> $SAVELOG
    echo >> $SAVELOG
  fi
}

#keep wifi alive
keep_wifi_alive()
{
  # pint count
  COUNT=10
  # reset percentage
  PERCENT=70
  # ping timeout
  WAIT=3
  LAST=1
  while [ 1 ]; do
    
    WIFI=`/usr/local/share/script/t_gpio.sh 11`
    # if wifi off then wait 5
    if [ $WIFI -eq 0 ]; then
      sleep 5
    # if wifi just turn on
    elif [ $LAST -eq 0 ]; then
      sleep 5
      wifi_station
    # wifi on
    else
      WLANDOWN=`ifconfig | grep wlan0 | awk '{ print $1 }'`
      if [ "${WLANDOWN}" == "" ]; then
        # save log to wifi.log
        if [ $WLOG -eq 1 ]; then
          echo 'wlan0_is_down [' `cat /proc/uptime` ']' >> $SAVELOG
        fi
        sleep 10
        WIFI=`/usr/local/share/script/t_gpio.sh 11`
        # if wifi on then restart wifi mode
        if [ $WIFI -eq 1 ]; then
          /usr/local/share/script/bcm4330_restart.sh
          # save log to wifi.log
          if [ $WLOG -eq 1 ]; then
            echo 'bcm4330_restart [' `cat /proc/uptime` ']' >> $SAVELOG
          fi
          sleep 10
          wifi_station
          sleep 10
        fi
      fi
      APMODE=`ping -W 1 -c 1 192.168.42.1 | grep received`
      if [ "${APMODE}" != "" ]; then
        # save log to wifi.log
        if [ $WLOG -eq 1 ]; then
          echo 'back_to_ap_mode [' `cat /proc/uptime` ']' >> $SAVELOG
        fi
        sleep 5
        WIFI=`/usr/local/share/script/t_gpio.sh 11`
        # if wifi on then restart wifi mode
        if [ $WIFI -eq 1 ]; then
          wifi_station
        fi
      else
        result=$(ping -W $WAIT -c $COUNT $GATE | grep 'received' | awk -F',' '{ print $2 }' | awk '{ print $1 }')
        if [ $result -lt $(( $COUNT * $PERCENT / 100 )) ]; then
          # save log to wifi.log
          if [ $WLOG -eq 1 ]; then
            echo 'ping_gateway_timeout [' `cat /proc/uptime` ']' >> $SAVELOG
          fi
          sleep 5
          WIFI=`/usr/local/share/script/t_gpio.sh 11`
          # if wifi on then restart wifi mode
          if [ $WIFI -eq 1 ]; then
            wifi_station
          fi
        fi
      fi
    fi
    LAST=$WIFI
  done
}

# Program starts from here
read_wireless
sleep 1
# save log to wifi.log
SAVELOG=/tmp/fuse_d/wifi.log
WLOG=0
if [ -f $SAVELOG ]; then
  WLOG=1
  echo 'System Power Up Time [' `cat /proc/uptime` ']' > $SAVELOG
fi

if [ -e /tmp/wifi.loaded ]; then
  t=1
else
  t=5
fi

if [ $WLOG -eq 1 ]; then
  echo 'wait_for_wlan0 [' `cat /proc/uptime` ']' `ifconfig` >> $SAVELOG
fi

APMODE=`ping -W 1 -c 1 192.168.42.1 | grep received`
while [ "${APMODE}" == "" ]; do
  sleep $t
  APMODE=`ping -W 1 -c 1 192.168.42.1 | grep received`
done

if [ $WLOG -eq 1 ]; then
  echo 'start_wifi_station [' `cat /proc/uptime` ']' `ifconfig` >> $SAVELOG
  echo `cat ${WPAS}` >> $SAVELOG
fi

# if wifi on start wifi mode
wifi_station
sleep 1
keep_wifi_alive
