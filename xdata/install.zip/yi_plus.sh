#!/bin/sh

# network_message_daemon doesn't receive some messages from the uItron
# when wifi is off so fool uItron into thinking that wifi is on 
sleep 3 && /usr/local/share/script/t_gpio.sh 11 1 && sleep 1 && /usr/bin/boot_done 1 2 1 &

# run yi_plus
sleep 3 && killall network_message_daemon && network_message_daemon 2>&1 >> /tmp/yi_plus.log &
sleep 5 && /tmp/fuse_a/custom/yi_plus 2>&1 >> /tmp/yi_plus.log &

